using System.Reflection;

[assembly: AssemblyTitle("Menees.Diffs.Controls")]
[assembly: AssemblyDescription("Menees Differencing Windows Forms Controls")]
